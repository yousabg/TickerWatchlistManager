package com.mobile.tickerwatchlistmanager;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.LinkedList;

public class TickerViewModel extends ViewModel{

    private MutableLiveData<String> tickerData;
    MutableLiveData<LinkedList<String>> tickers;

    public LiveData<LinkedList<String>> getTickers() {
        if (tickers == null) {
            tickers = new MutableLiveData<>();
            loadTickers();
        }
        return tickers;
    }

    private void loadTickers() {
        LinkedList<String> ltickers = new LinkedList<String>();
        ltickers.add("BAC");
        ltickers.add("AAPL");
        ltickers.add("DIS");
        tickers.setValue(ltickers);
    }

    public void setTickerData(String ticker) {
        if (tickers == null) {
            tickers = new MutableLiveData<>();
            loadTickers();
        }
        if (tickerData == null) {
            tickerData = new MutableLiveData<>();
            loadTickers();
        }
        String s = ticker;
        LinkedList<String> newTickers = tickers.getValue();
        if (newTickers.size() < 6) {
            this.tickerData.setValue(s);
            newTickers.add(s);
        } else {
            this.tickerData.setValue(s);
            newTickers.remove(6);
            newTickers.add(s);
        }
        tickers.setValue(newTickers);
    }


}

