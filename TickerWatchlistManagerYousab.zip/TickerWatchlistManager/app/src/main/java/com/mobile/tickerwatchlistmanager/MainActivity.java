package com.mobile.tickerwatchlistmanager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProvider;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    WebView mWebView;
    TickerViewModel model;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        model = new ViewModelProvider(this).get(TickerViewModel.class);


        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            String[] perms = new String[]{Manifest.permission.RECEIVE_SMS};
            ActivityCompat.requestPermissions(this, perms, 101);
            requestPermissions(perms, 101);
        }


        Intent intent = getIntent();
        String message = intent.getStringExtra("sms");
        if (message != null && message.contains("Ticker<<") && message.contains(">>")) {
            String ticker = message.substring(message.indexOf("<") + 2, message.indexOf(">"));
            model.setTickerData(ticker);

        } else {
            Toast.makeText(getApplicationContext(), "No valid watchlist entry was found.", Toast.LENGTH_LONG).show();
        }
    }

//    protected void onNewIntent(Intent intent) {
//        super.onNewIntent(intent);
//        String message = intent.getStringExtra("sms");
//        if (message != null && message.contains("Ticker<<") && message.contains(">>")) {
//            String ticker = message.substring(message.indexOf("<") + 1, message.indexOf(">"));
//            model.setTickerData(ticker);
//
//        } else {
//            Toast.makeText(getApplicationContext(), "No valid watchlist entry was found.", Toast.LENGTH_LONG).show();
//        }
//    }

}